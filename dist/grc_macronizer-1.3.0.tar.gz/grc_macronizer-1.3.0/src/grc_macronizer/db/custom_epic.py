custom_epic = {
    "ἀποτίνω": "ἀποτί_νω", # Att. has α^
}