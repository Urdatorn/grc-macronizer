from grc_utils import syllabifier, count_dichrona_in_open_syllables, open_syllable_in_word, word_with_real_dichrona

print(syllabifier("Αἰγύπτου"))

print(count_dichrona_in_open_syllables("Αἰγύπτου"))

print(open_syllable_in_word("Αἰ", "Αἰγύπτου"))

print(word_with_real_dichrona("Αἰ"))