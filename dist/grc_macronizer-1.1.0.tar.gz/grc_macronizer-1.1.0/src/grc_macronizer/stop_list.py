'''
List of words that in any genre and period will most likely yield incorrect disambiguations.

Whether to use the stop list or not in a given production situation comes down to whether a wrong disambiguation is worse than a lacking disambiguation.

'''

stop_list = [
]